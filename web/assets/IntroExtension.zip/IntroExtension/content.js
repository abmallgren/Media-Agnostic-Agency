chrome.storage.sync.get(['maProfile'], (result) => {
    window.postMessage({ type: 'Media_Agnostic_Introduction_Profile', payload: result.maProfile }, '*');
});

window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'Media_Agnostic_Introduction') {
        chrome.storage.sync.get(['maProfile'], (result) => {
            window.postMessage({ type: 'Media_Agnostic_Introduction_Profile', payload: result.maProfile }, '*');
        }).then(console.log);
    }
});

window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'Media_Agnostic_Profile') {
        chrome.storage.sync.set({ maProfile: event.data.payload }, () => { });
        chrome.storage.sync.get(['maProfile'], (result) => {
            console.log(result);
        });
    }
});