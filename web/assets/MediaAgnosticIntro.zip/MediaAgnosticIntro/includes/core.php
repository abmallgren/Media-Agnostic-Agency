<?php

namespace MediaAgnosticIntro;

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter('use_curl_transport', '__return_false');

add_action('admin_menu', function () {
    add_menu_page(
        'Media Agnostic Introductions',
        'Media Agnostic Intro',
        'manage_options',
        'media-agnostic-intro',
        __NAMESPACE__ . '\\media_agnostic_intro_page'
    );
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_media-agnostic-intro') {
        return;
    }

    wp_enqueue_style(
        'media-agnostic-intro-admin-style',
        plugin_dir_url(__FILE__) . '../assets/admin.css'
    );
});

add_action('init', function () {
    wp_register_script(
        'media-agnostic-intro-script',
        plugin_dir_url(__FILE__) . '../assets/media-agnostic-intro.js',
        [],
        null,
        true // load in footer
    );
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('media-agnostic-intro-script');
});

    
function media_agnostic_intro_page() {

    ?>
    <div class="wrap">
        <h1>Media Agnostic Intros</h1>
        <div id="ma-intros-table-container">
            <table id="ma-intros-table" class="widefat fixed">
                <thead>
                    <tr>
                        <th>IP</th>
                        <th>URL</th>
                        <th>Profile</th>
                        <th>Occurred</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be loaded here via AJAX -->
                </tbody>
            </table>
            <div id="ma-intros-pagination" style="margin-top: 20px;"></div>
        </div>
        <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            let paged = 1;
            const limit = 50;
            function loadIntros(page) {
                paged = page;
                const tableBody = document.querySelector('#ma-intros-table tbody');
                tableBody.innerHTML = '<tr><td colspan="3">Loading...</td></tr>';
                fetch(ajaxurl + '?action=get_ma_intros&paged=' + page)
                    .then(res => res.json())
                    .then(res => {
                        if (!res.success) return;
                        const data = res.data.data;
                        const total = res.data.total;
                        let rows = '';
                        if (data.length === 0) {
                            rows = '<tr><td colspan="3">No introductions found.</td></tr>';
                        } else {
                            data.forEach(row => {
                                rows += `<tr><td>${row.ip}</td><td>${row.url}</td><td>${row.profile}</td><td>${row.occurred_at}</td></tr>`;
                            });
                        }
                        tableBody.innerHTML = rows;
                        renderPagination(total, page, limit);
                    });
            }

            function renderPagination(total, page, limit) {
                const container = document.getElementById('ma-intros-pagination');
                const totalPages = Math.ceil(total / limit);
                let html = '';
                if (totalPages > 1) {
                    for (let i = 1; i <= totalPages; i++) {
                        html += `<button class="button" ${i === page ? 'disabled' : ''} data-page="${i}">${i}</button> `;
                    }
                }
                container.innerHTML = html;
                Array.from(container.querySelectorAll('button')).forEach(btn => {
                    btn.addEventListener('click', function() {
                        loadIntros(parseInt(this.getAttribute('data-page')));
                    });
                });
            }

            loadIntros(1);
        });
        </script>
    </div>
    <?php
}

?>