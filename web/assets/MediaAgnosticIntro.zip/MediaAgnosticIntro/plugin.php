<?php
/**
 * Plugin Name: Media Agnostic Intro
 * Description: Prompts user to provide Media Agnostic Intro profile from the user for audience intelligence reasons.
 * Version: 1.0
 * Author: Anthony Brian Mallgren
 * License: GPLv2
 */

namespace MediaAgnosticIntro;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once plugin_dir_path(__FILE__) . 'includes/core.php';
require_once plugin_dir_path(__FILE__) . 'public/client.php';

function install() {
    global $wpdb;

    $table = $wpdb->prefix . 'ma_introductions';

    $charset = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `ip` VARCHAR(64) NOT NULL,
        `url` TEXT NOT NULL,
        `profile` TEXT NOT NULL,
        occurred_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

register_activation_hook(__FILE__, __NAMESPACE__ . '\\install');

?>