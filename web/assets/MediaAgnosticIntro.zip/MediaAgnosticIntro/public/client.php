<?php

namespace MediaAgnosticIntro;

if ( ! defined( 'ABSPATH' ) ) exit;

add_action('wp_ajax_add_ma_intro', __NAMESPACE__ . '\\add_ma_intro');
add_action('wp_ajax_nopriv_add_ma_intro', __NAMESPACE__ . '\\add_ma_intro');

add_action('wp_ajax_get_ma_intros', __NAMESPACE__ . '\\get_ma_intros');
add_action('wp_ajax_nopriv_get_ma_intros', __NAMESPACE__ . '\\get_ma_intros');

function add_ma_intro() {
    global $wpdb;

    $data = json_decode(file_get_contents('php://input'), true);

    $ip      = get_requester_ip();
    $url     = esc_url_raw($data['url'] ?? '');
    $profile = wp_kses_post($data['profile'] ?? '');

    $table = $wpdb->prefix . 'ma_introductions';

    $wpdb->insert($table, [
        'ip' => $ip,
        'url' => $url,
        'profile' => $profile
    ]);

    wp_send_json_success("Introduction added");
}

function get_ma_intros() {
    global $wpdb;

    $paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $limit = 50;
    $offset = ($paged - 1) * $limit;

    $table = $wpdb->prefix . 'ma_introductions';
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT ip, url, profile, occurred_at FROM $table ORDER BY occurred_at DESC LIMIT %d OFFSET %d",
        $limit, $offset
    ), ARRAY_A);

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");

    wp_send_json_success([
        'data' => $results,
        'total' => intval($total),
        'paged' => $paged,
        'limit' => $limit
    ]);
}

function get_requester_ip() {
    $keys = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];

    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            return trim($ipList[0]);
        }
    }

    return null;
}
