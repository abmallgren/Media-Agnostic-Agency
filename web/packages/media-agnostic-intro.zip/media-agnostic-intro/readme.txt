=== Media Agnostic Intro ===
Contributors: anthonybmallgren
Donate link: https://buy.stripe.com/7sY6oIgk39eq4Q5cl914400
Tags: audience intelligence, marketing
Requires at least: 4.7
Tested up to: 6.9
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Allows user participants in Media Agnostic Intro to provide demographic and interest based information.

== Description ==

The Media Agnostic Intro extension can be installed in browsers that support Chrome extensions, such as Chrome, Edge, Yandex, and Kiwi. 
A profile may be created (can create a simple starter profile at https://mediaagnostic.agency/intro). When a user browses to a site 
participating in Media Agnostic Intro, the information is then logged in the site data and can be viewed from the wp-admin section. 

== Frequently Asked Questions ==

= Will my data be shared with websites without my permission? =

The data is shared with any participating site. If you would like to keep your information private, you can disable the extension or use
a private window (Edge: InPrivate/Chrome: Incognito).

== Screenshots ==

1. Simple in-site data viewer for novice users.

== Changelog ==

= 1.0 =
* Initial version.

== Upgrade Notice ==